export PATH=${PATH}:/usr/local/addons/hm-tools/bin
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/usr/local/addons/hm-tools/lib
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/usr/local/addons/hm-tools/lib/expect5.45.3
