export PATH=${PATH}:/usr/local/addons/hm-tools/bin
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:/usr/local/addons/hm-tools/lib
export MC_PROFILE_ROOT=/usr/local/addons/hm-tools/
export TERM=xterm
